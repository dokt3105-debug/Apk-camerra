# Camera View

<div align="center">

![Logo](app/src/main/res/mipmap-hdpi/ic_launcher_round.webp)

</div>

It is a simple minimal camera viewer android app. 

---

## Android APK
Download the APK from the GitHub Releases:

👉 [**Download APK**](https://github.com/akarshit-1609/camera-view/releases/download/v1.2.1/camera-view-v1.2.1.apk)

## Features
 - 📷 Fullscreen Camera — Displays the camera feed across the entire screen.
 - 🧼 Clean UI — No buttons, menus, overlays, or unnecessary interface elements.
 - 🎯 Camera-Only Experience — The app focuses exclusively on displaying the live camera preview.
 - 🚫 No Extra Functions — No filters, settings, controls, or additional features.
 - ⚡ Simple & Lightweight — Built around a single purpose with a minimal interface.
 - 📱 Immersive Display — Uses the available screen space for an uninterrupted camera view.
 - 👁️ Distraction-Free — Ideal when you simply want to see the camera feed without visual clutter.

### Concept

**The goal of this app is simplicity: open the app and see the camera.**<br>
There are no controls to learn and no unnecessary UI elements—just a clean, fullscreen camera preview.

---

## How It Works
The app uses a **double-tap gesture** to toggle between the two available cameras.

### Camera Toggle
 - Double-tap anywhere on the screen.
 - If the **back camera** is active, it switches to the **front camera**.
 - If the **front camera** is active, it switches to the **back camera**.

 ---

## Use Case
 - This app can be useful for situations where a continuously visible camera feed is preferred without additional controls or interface distractions.

## Design Philosophy

 - One screen. One purpose. Just the camera.

The interface intentionally stays out of the way so the camera preview remains the only visible element.

---

## License

This project is licensed under the MIT License. See the `LICENSE` file for details.

---
